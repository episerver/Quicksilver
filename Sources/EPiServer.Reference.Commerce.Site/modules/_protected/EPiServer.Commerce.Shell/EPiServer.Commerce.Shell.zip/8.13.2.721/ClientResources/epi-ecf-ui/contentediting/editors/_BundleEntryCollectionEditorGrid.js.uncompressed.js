﻿/* TODO: Much borrowed from AssociationCollectionEditor - consolidate */
define("epi-ecf-ui/contentediting/editors/_BundleEntryCollectionEditorGrid", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",
    "dojo/aspect",
    "dojo/Deferred",
    "dojo/when",
    "dojo/Stateful",
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dgrid/editor",
    "dgrid/Selection",
    "dijit/form/Button",
    "dgrid/OnDemandGrid",
    "epi/dependency",
    "epi/string",
    "epi/shell/_ContextMixin",
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi-cms/dgrid/DnD",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/dialog/Confirmation",
    "epi-cms/widget/ContentSelectorDialog",
    "epi-cms/contentediting/editors/_AddItemDialogMixin",
    "epi-cms/core/ContentReference",
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",
    "../ModelSupport",
    "./_CollectionEditorDndMixin",
    "./_GridWithDropContainerMixin",
     "../../dgrid/_ClickablePathColumnMixin",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.relationcollectioneditor"
],
function (
    array,
    declare,
    lang,
    domConstruct,
    aspect,
    Deferred,
    when,
    Stateful,
    _Widget,
    _TemplatedMixin,
    editor,
    Selection,
    Button,
    Grid,
    dependency,
    epiString,
    _ContextMixin,
    ButtonBuilder,
    Dialog,
    _EditorMetadataMixin,
    DnD,
    _FocusableMixin,
    _ModelBindingMixin,
    Confirmation,
    ContentSelectorDialog,
    _AddItemDialogMixin,
    ContentReference,
    WithContextMenu,
    formatters,
    ModelSupport,
    _CollectionEditorDndMixin,
    _GridWithDropContainerMixin,
    _ClickablePathColumnMixin,
    resources
) {
    return declare([_Widget, _TemplatedMixin, _ModelBindingMixin, _AddItemDialogMixin, _FocusableMixin, _CollectionEditorDndMixin, _ContextMixin, _GridWithDropContainerMixin], {

        grid: null,

        storeKey: "epi.commerce.relation",

        itemType: "EPiServer.Commerce.Shell.Rest.Models.RelationModel",

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.productContent, ModelSupport.linkTypeIdentifier.relation],

        includedColumns: ["ContentTypeIdentifier", "Name", "Path", "Quantity", "GroupName"],

        editableColumns: ["Quantity", "GroupName"],

        // Grid action column name
        cellActionName: "epiGridAction",

        itemEditorType: ContentSelectorDialog,

        noDataMessage: resources.nodatamessage,

        addLabelText: resources.addlabel,

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.roots) {
                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors"),
                    settings = contentRepositoryDescriptors.catalog;
                this.roots = settings.roots;
            }
            var builder = new ButtonBuilder({ settings: { showLabel: true } }),
                command = this.model.getListCommand();
            builder.create(command, this.commandTargetNode);

            // Set up metadata capable grid type
            var EditorGrid = declare([Grid, Selection, editor, _EditorMetadataMixin, WithContextMenu, DnD, _ClickablePathColumnMixin], {});

            // Get metadata for itemType
            when(this.model.metadataManager.getMetadataForType(this.itemType), lang.hitch(this, function (metadata) {
                // Set up columns object with one column for context menu
                var columns = [
                    {
                        field: "contentTypeIdentifier",
                        renderHeaderCell: function () { }, // no header
                        get: function (object) {
                            return object.contentTypeIdentifier;
                        },
                        label: "",
                        formatter: formatters.contentIcon,
                        className: "epi-columnIcon16x16",
                        sortable: false
                    },
                    {
                        field: this.cellActionName,
                        renderHeaderCell: function () { }, // no header
                        renderCell: lang.hitch(this, function (object, value, node, options) {
                            var builder = new ButtonBuilder({ settings: { showLabel: false } }),
                                commands = this.model.getCommands(this.grid, null);

                            array.forEach(commands, function(command) {
                                builder.create(command, node);
                            });
                        }),
                        className: "epi-columnNarrow",
                        sortable: false
                    }],
                    store = dependency.resolve("epi.storeregistry").get(this.storeKey),
                    // Create grid
                    grid = this.grid = new EditorGrid({
                        store: store,
                        minWidth: 100,
                        noDataMessage: this.noDataMessage,
                        selectionMode: "single",
                        "class": "epi-plain-grid epi-plain-grid-modal epi-plain-grid--margin-bottom epi-plain-grid--cell-borders",
                        columns: columns,
                        metadata: {
                            properties: metadata.properties,
                            gridIncluded: this.includedColumns,
                            gridEditable: this.editableColumns
                        },
                        dndSourceTypes: [ModelSupport.linkTypeIdentifier.relation],
                        dndParams: {
                            copyOnly: true,
                            accept: this.allowedDndTypes || [],
                            creator: lang.hitch(this, this._dndNodeCreator)
                        }
                    }, this.gridNode);
                this.own(grid,
                    this.model.on("itemAdded", lang.hitch(this, function (e) {
                        this.grid.refresh();
                    })),
                    this.model.on("itemRemoved", lang.hitch(this, function (e) {
                        this.grid.refresh();
                    })),
                    this.model.on("itemSaved", lang.hitch(this, function () {
                        this.grid.refresh();
                    })),
                    this.model.watch("contentLink", lang.hitch(this, function (property, oldValue, newValue) {
                        // Set query even if the content link is the same, to update bundle entry grid
                        this._updateGridQuery(newValue);
                        grid.resize();
                    })),
                    // Listen remove command event
                    this.model.on("removeCommandEvent", lang.hitch(this, function () {
                        // Show confirmation dialog to confirm delete bundle item
                        when(this._showConfirmation(this.deleteConfirmationTitle, this.deleteConfirmationDescription), lang.hitch(this, function () {
                            if (this.model) {
                                var remove = [];
                                for (var selected in this.grid.selection) {
                                    if (this.grid.selection.hasOwnProperty(selected)) {
                                        remove.push(this.model.store.get(selected));
                                    }
                                }
                                return this.model.removeItems(remove);
                            }
                        }));
                    }))
                );
                this.styleGrid();
                this._setupDnD();
                when(this.getCurrentContext(), lang.hitch(this, function(currentContext){
                    this._updateGridQuery(currentContext.id);
                    this.grid.startup();
                }));
            }));

        },

        _updateGridQuery: function(value){
            var queryOptions = this.getQueryOptions(value);
            this.grid.set("query", queryOptions.query, queryOptions.options);
        },

        getQueryOptions: function(referenceId) {
            return {
                query: {
                    referenceId: new ContentReference(referenceId).createVersionUnspecificReference().toString(),
                    relationTypes: [this.relationType]
                },
                options: {
                    ignore: ["referenceId", "relationTypes"]
                }
            };
        },

        _addItem: function (item) {
            when(this._dndGetItemData(item), lang.hitch(this, function (itemData) {
                return this.model.addItem(itemData);
            }));
        },

        resize: function () {
            this.inherited(arguments);

            if (this.grid) {
                this.grid.resize();
            }
        },

        _getDialogTitleText: function () {
            return this.addLabelText;
        },

        _createItemEditor: function () {
            return new this.itemEditorType({
                canSelectOwnerContent: false,
                showButtons: false,
                roots: this.roots,
                allowedTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.productContent],
                showAllLanguages: false
            });
        },

        _dndGetItemData: function (item) {
            return when(item.data, lang.hitch(this, function (data) {
                return this._createItem(data.contentLink, data.name);
            }));
        },

        _createItem: function (targetLink, name) {
            return {
                name: name || targetLink,
                groupName: "Default",
                quantity: 1,
                sortOrder: 0,
                source: this.model.get("contentLink"),
                target: targetLink,
                type: this.relationType
            };
        },

        onExecuteDialog: function () {
            var item = this._itemEditor.get("value");
            this._addItem({ data: { contentLink: item } }, true);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("value", value);

            if (this.model) {
                this.model.set("contentLink", value);
            }
        },

        destroy: function () {
            // summary:
            //      Destroy the object.

            if (this.grid) {
                this.grid.destroy();
                this.grid = null;
            }

            this.inherited(arguments);
        },

        _showConfirmation: function (title, description) {
            // summary:
            //      Wrap epi.shell.widget.dialog.Confirmation for short type
            //      and return deferred object
            // description:
            //      String: Text to display on dialog
            // tags:
            //      private

            var deferred = new Deferred();

            var dialog = new Confirmation({
                destroyOnHide: true,
                title: epiString.toHTML(title),
                description: epiString.toHTML(description),
                onAction: function (confirmed) {
                    if (confirmed) {
                        deferred.resolve();
                    } else {
                        deferred.cancel();
                    }
                }
            });
            dialog.show();

            return deferred.promise;
        }
    });
});
