define("epi-ecf-ui/widget/MarketingToolbar", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/when",
    "epi/shell/layout/ToolbarContainer",
    "epi/shell/widget/ToolbarLabel",
    "epi/shell/widget/ToolbarSet",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar"
], function (declare, lang, all, when, ToolbarContainer, ToolbarLabel, ToolbarSet, resources) {

    return declare([ToolbarSet], {
        // tags:
        //      public

        // currentContext: [public] Object
        //      An object with the current context information.
        currentContext: null,

        // _setupPromise: [private] String
        //      The setup children promise.
        _setupPromise: null,

        buildRendering: function() {
            // summary:
            //      Constructs the toolbar container and starts the children setup process.
            // tags:
            //      protected

            this.inherited(arguments);

            // Setup the children items in the toolbar.
            when(this._setupPromise = this.setupChildren(), lang.hitch(this, function () {
                // Update the toolbar items with the current model.
                this.updateChildren();
            }));
        },

        isSetup: function () {
            // summary:
            //      Wait for setup to finish.
            // tags:
            //      protected

            return this._setupPromise;
        },

        setupChildren: function() {
            // summary:
            //      Setup the items in the toolbar. Inheriting classes should extend this to add more items to the toolbar.
            // tags:
            //      protected

            var toolbarGroups = [
            {
                name: "leading",
                type: "toolbargroup",
                settings: { region: "leading" }
            },
            {
                name: "center",
                type: "toolbargroup",
                settings: { region: "center" }
            },
            {
                name: "trailing",
                type: "toolbargroup",
                settings: { region: "trailing" }
            }];

            var toolbarItems = [];
            
            return this.add(toolbarGroups).then(lang.hitch(this, function () {
                    return this.add(toolbarItems);
                })
            );
        },

        updateChildren: function() {
            // summary:
            //      Update the toolbar items. This method is called on startup and whenever the current context is set.
            // tags:
            //      protected
        },

        update: function(data) {
            // summary:
            //      Update the toolbar with new data.
            // data:
            //      Toolbar data model. Expected properties are: currentContext
            // tags:
            //      public

            if (!data) {
                return;
            }

            this.currentContext = data.currentContext;

            when(this.isSetup(), lang.hitch(this, this.updateChildren));
        }
    });
});