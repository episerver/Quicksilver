require({cache:{
'url:epi-ecf-ui/widget/templates/ExportedOrderReportsList.html':"﻿<div data-dojo-type=\"dijit/layout/ContentPane\" class=\"epi-list-container\">\r\n    <div data-dojo-attach-point=\"downloadLinksContainer\" class=\"epi-view-container\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/ExportedOrderReportsList", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",
    "dojo/when",
    // dijit
    "epi/shell/_ContextMixin",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    // template
    "dojo/text!./templates/ExportedOrderReportsList.html",
    "epi/i18n!epi/cms/nls/commerce.report.exportedorderreportslist"
], function (
    // dojo
    declare,
    lang,
    domConstruct,
    when,
    // dijit
    _ContextMixin,
    _TemplatedMixin,
    _WidgetBase,
    // template
    template,
    reportingResources
) {
        // module:
        //      epi-ecf-ui.widget.ExportedOrderReportsList
        // tags:
        //      protected

        return declare([_WidgetBase, _TemplatedMixin, _ContextMixin], {
            // summary:
            //      Report widget.
            // tags:
            //      public

            resources: reportingResources,

            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                this._renderDownloadLinks();
            },

            _renderDownloadLinks: function () {
                // summary:
                //      Renders report download links
                // tags:
                //      private

                when(this.getCurrentContext()).then(function (context) {
                    var exportedFilesData = context.data;

                    if (!(exportedFilesData instanceof Array) || exportedFilesData.length === 0) {
                        // No files, do nothing.

                        domConstruct.place("<span>" + this.resources.nofilesfound + "</span>", this.downloadLinksContainer);

                        return;
                    }

                    var reportLinkTags = "";
                    for (var itemIndex in exportedFilesData) {
                        var reportLinkTag = lang.replace("<li><a class=\"epi-visibleLink\" href=\"{downloadUrl}\">{fileName}</a><li>", {
                            fileName: exportedFilesData[itemIndex].name,
                            downloadUrl: exportedFilesData[itemIndex].downloadUrl
                        });

                        reportLinkTags += reportLinkTag;
                    }

                    domConstruct.place("<ul>" + reportLinkTags + "</ul>", this.downloadLinksContainer);
                }.bind(this));
            }
        });
    });