﻿define("epi-ecf-ui/component/Campaigns", [
// dojo
    "dojo/_base/declare",
// epi cms
    "epi-cms/asset/HierarchicalList",
// Resources
    "epi/i18n!epi/cms/nls/commerce.components.marketing"
],

function (
// dojo
    declare,
// epi cms
    HierarchicalList,
// Resources
    res) {
    // module:
    //      epi-ecf-ui.component.Campaigns

    return declare([HierarchicalList], {
        // summary:
        //      Campaigns component.
        // tags:
        //      public

        noDataMessages: res.nodatamessages,

        postscript: function () {
            // summary: Overridden to remove all commands.
            //
            // tag:
            //      public override

            this.inherited(arguments);
            this.model.set("commands", []);
        },

        setupContextMenu: function () {
            // summary: Set up the context menu. Overridden to not add context menu on the campaign tree gadget.
            //
            // tag:
            //      public override
        }
    });
});