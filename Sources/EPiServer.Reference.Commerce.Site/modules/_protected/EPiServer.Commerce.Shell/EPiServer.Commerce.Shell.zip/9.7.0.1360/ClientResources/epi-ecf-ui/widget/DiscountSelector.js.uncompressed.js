require({cache:{
'url:epi-ecf-ui/widget/templates/DiscountSelector.html':"﻿<div class=\"dijitReset dijitInputField dijitInputContainer dijitInline epi-resourceInputContainer epi-categorySelector\" id=\"widget_${id}\">\n    <div data-dojo-attach-point=\"textNode\" class=\"dijit dijitReset dijitInline dijitInlineTable dijitLeft dijitTextBox displayNode epi-categoriesGroup epi-textbox-tag\">\n    </div>\n    <div data-dojo-type=\"dijit/form/Button\" data-dojo-attach-event=\"onClick: _onButtonClick\" \n         data-dojo-attach-point=\"button\" data-dojo-props=\"iconClass: 'epi-iconPlus epi-icon--medium', showLabel: false\"></div>\n</div>"}});
﻿define("epi-ecf-ui/widget/DiscountSelector", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Button",
    "dijit/Tooltip",
// epi
    "epi/epi",
    "epi/shell/dgrid/util/misc",
// epi-cms
    "epi-cms/core/ContentReference",
    "epi-cms/widget/_HasChildDialogMixin",

// epi-ecf-ui
    "./_MarketingItemTag",
    "../MarketingUtils",

// resources
    "dojo/text!./templates/DiscountSelector.html",
    "epi/i18n!epi/nls/commerce.widget.discountselector"
],

function (
// dojo
    array,
    declare,
    lang,
    domConstruct,

// dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    Button,
    Tooltip,

// epi
    epi,
    shellMisc,

// epi-cms
    ContentReference,
    _HasChildDialogMixin,

// epi-ecf-ui
    _MarketingItemTag,
    MarketingUtils,

// resources
    template,
    resources
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _HasChildDialogMixin], {
        // tags: Represents a widget to select multiple campaign, discount.
        //      internal

        templateString: template,

        resources: resources,

        // excludedLink: [public] String
        //      Content reference of the discount, which should not be displayed on the tree.
        excludedLink: null,

        // tags:
        //    protected
	    value: null,

        // dialog: [public] epi/shell/widget/dialog/Dialog
        //      Represent the dialog which contains the tree, and will be opened when selector button is clicked.
        dialog: null,

        // _maxItemTagsDisplay: [private] int
        //      Display maximum 2 item tags (in one line), if there are more selected items then append an ellipsis.
        _maxItemTagsDisplay: 2,

        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            //
            // value:
            //    The value
            // tags:
            //    public, callback
        },

        _setValueAttr: function (value) {
            //summary:
            //    Value's setter.
            //
            // value: array of content data.
            //    Value to be set.
            //
            // tags:
            //    protected

            value = !value ? [] : !lang.isArray(value) ? [value] : value;
            this._sortItems(value);
            this._set("value", value);
            this._updateTextNode(this.value);
            this.onChange(this.value);
        },

        _convertTypeIdentifierToNumber: function (item) {
            //summary:
            //    convert type identifier of a marketing item to number
            //    in order to compare two items
            //
            // item: marketing item.
            //
            // tags:
            //    private

            return MarketingUtils.isPromotionData(item.typeIdentifier) ? 2 : MarketingUtils.isSalesCampaign(item.typeIdentifier) ? 1 : 0;
        },

        _sortItems: function (value) {
            //summary:
            //    sort items: root first, then campaigns, and finally promotions.
            //
            // value: array of content data.
            //
            // tags:
            //    private
            
            value.sort(lang.hitch(this, function (a, b) {
                return this._convertTypeIdentifierToNumber(a) - this._convertTypeIdentifierToNumber(b);
            }));
        },

        _updateTextNode: function (value) {
            //summary:
            //    update the text node.
            //
            // value: array of content link.
            //
            // tags:
            //    private

            this.textNode.innerHTML = '';
            
            var count = 0;
            var displayedItems = [];
            array.some(value, function (item) {
                if (count < this._maxItemTagsDisplay) {
                    this._renderMarketingItemTag(item);
                    displayedItems.push(item);
                    count++;
                    return false;
                } else {
                    var ellipsisNode = domConstruct.create("span", { innerHTML: "..." });
                    new Tooltip({
                        connectId: ellipsisNode,
                        label: this._getHiddenItemPaths(this.value, displayedItems)
                    });
                    domConstruct.place(ellipsisNode, this.textNode);
                    return true;
                }
            }, this);
            this._renderEmptyTextIfNeeded();
        },

        _getHiddenItemPaths: function(items, displayedItems) {
            var otherItemPaths = '';
            array.forEach(items, function (item) {
                if (displayedItems.indexOf(item) < 0) {
                    if (MarketingUtils.isPromotionData(item.typeIdentifier)) {
                        otherItemPaths += "<div>" + shellMisc.htmlEncode(item.properties.campaignName + " / " + item.name) + "</div>";
                    } else {
                        otherItemPaths += "<div>" + shellMisc.htmlEncode(item.name) + "</div>";
                    }
                }
            });

            return otherItemPaths;
        },

        _renderMarketingItemTag: function (item) {
            var itemTag = new _MarketingItemTag({
                item: item
            });

            this.own(itemTag, itemTag.on("removeClick", lang.hitch(this, function (contentLink) {
                domConstruct.destroy(itemTag.id);
                itemTag.destroy();
                this._onRemoveClick(contentLink);
            })));

            domConstruct.place(itemTag.domNode, this.textNode);
        },

        _renderEmptyTextIfNeeded: function () {
            if (!this.value || this.value.length === 0) {
                domConstruct.create('div', {
                    innerHTML: this.resources.noexclusionschosen,
                    "class": "epi-categoriesGroup__message"
                }, this.textNode, "only");
            }
        },

        _onRemoveClick: function (contentLink) {
            var itemIndex = -1;
            array.some(this.value, function (item, index) {
                if(ContentReference.compareIgnoreVersion(contentLink, item.contentLink)) {
                    itemIndex = index;
                    return true;
                }
            });

            if (itemIndex === -1) {
                return;
            }

            this.value.splice(itemIndex, 1);
            this.set("value", this.value);
        },

        focus: function () {
            this.button.focus();
        },

        _onDialogShow: function () {
            this.dialog.content.set("excludedLink", this.get("excludedLink"));
            this.dialog.content.set("value", this.get("value"));
        },

        _onDialogExecute: function () {
            var oldValue = this.get('value');
            var dialogContentValue = this.dialog.content.get('value');

            if (!epi.areEqual(dialogContentValue, oldValue)) {
                this.set('value', this.dialog.content.get('value'));
            }

            this._destroyHandles();
        },

        _onDialogHide: function () {
            this._destroyHandles();
        },

        _onButtonClick: function () {
            //summary:
            //    Handle the add button click
            // tags:
            //    private

            if (this.dialog) {
                this._onDialogExecuteHandle = this.connect(this.dialog, 'onExecute', '_onDialogExecute');
                this._onDialogShowHandle = this.connect(this.dialog, 'onShow', '_onDialogShow');
                this._onDialogHideHandle = this.connect(this.dialog, 'onHide', '_onDialogHide');
                this.dialog.show(true);
            }
        },

        _destroyHandles: function () {
            this._onDialogExecuteHandle && this._onDialogExecuteHandle.remove();
            this._onDialogShowHandle && this._onDialogShowHandle.remove();
            this._onDialogHideHandle && this._onDialogHideHandle.remove();
        }
    });
});
