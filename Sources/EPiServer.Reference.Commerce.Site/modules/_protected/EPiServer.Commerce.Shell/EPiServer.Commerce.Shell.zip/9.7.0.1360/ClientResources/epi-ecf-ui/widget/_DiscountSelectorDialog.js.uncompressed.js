require({cache:{
'url:epi-ecf-ui/widget/templates/_DiscountSelectorDialog.html':"﻿<div>\n    <div data-dojo-attach-point=\"tree\" data-dojo-type=\"epi-ecf-ui/widget/DiscountTree\" data-dojo-props=\"root: ${root}\">\n    </div>\n</div>"}});
﻿define("epi-ecf-ui/widget/_DiscountSelectorDialog", [
// dojo
    "dojo/_base/declare",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",

// epi-ecf-ui
    "./DiscountTree",
    
// resources
    "dojo/text!./templates/_DiscountSelectorDialog.html"
],

function (
// dojo
    declare,

// dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,

// epi-ecf-ui
    DiscountTree,
    templates
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      Represents the widget which contains the Discount tree.
        // tags:
        //      private

        // templateString: [protected] String
        //      Widget's template string.
        templateString: templates,

        _setValueAttr: function (value) {
            this.tree.set("checkedItems", value);
        },

        _getValueAttr: function () {
            return this.tree.get("checkedItems");
        },

        _setExcludedLinkAttr: function (value) {
            if (this.tree && this.tree.model) {
                this.tree.model.set("excludedLink", value);
            }
        }
    });
});