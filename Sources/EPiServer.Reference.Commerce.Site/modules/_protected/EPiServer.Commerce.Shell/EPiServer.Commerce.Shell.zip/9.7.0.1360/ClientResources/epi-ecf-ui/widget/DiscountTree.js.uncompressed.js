﻿define("epi-ecf-ui/widget/DiscountTree", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dijit/Tree",

    "./_DiscountTreeNode",
    "./viewmodel/DiscountTreeStoreModel"
],

function (
    array,
    declare,
    lang,

    Tree,

    _DiscountTreeNode,
    DiscountTreeStoreModel
) {

    return declare([Tree], {
        // summary:
        //      Represents the tree which display all promotions available, and provides the ability of selecting multiple campaigns and discounts.
        // tags:
        //      internal

        postMixInProperties: function () {
            this.inherited(arguments);

            this.model = this.model || new DiscountTreeStoreModel({ root: this.root });
            this.persist = false;
        },

        postCreate: function () {
            this.inherited(arguments);

            // Disabling multiselect in tree
            this.dndController.singular = true;
        },

        _onNodeSelectChanged: function (node) {
            var rootNode = this.rootNode;

            if (node === rootNode) {
                this.model.set("checkedItems", node.get("checked") ? [node.item] : []);
                return;
            }

            var checkedItems = [];

            array.forEach(rootNode.getChildren(), function (campaignNode) {
                if (campaignNode.get("checked")) {
                    checkedItems.push(campaignNode.item);
                } else {
                    array.forEach(campaignNode.getChildren(), function (discountNode) {
                        if (discountNode.get("checked")) {
                            checkedItems.push(discountNode.item);
                        }
                    });
                }
            });

            this.model.set("checkedItems", checkedItems);
        },

        _setCheckedItemsAttr: function (value) {
            this.model.set("checkedItems", value);
            this._updateNodeSelectState(this.rootNode);
        },

        _getCheckedItemsAttr: function () {
            return this.model.get("checkedItems");
        },

        _updateNodeSelectState: function (node) {
            if (!node) {
                return;
            }

            var content = node.get("item");
            if (!content) {
                return;
            }

            var checked = this.model.updateContentSelectedState(content);
            if (!checked && node.isExpandable) {
                array.map(node.getChildren() || [], this._updateNodeSelectState, this);
            }
        },

        _createTreeNode: function (/*Object*/args) {
            // summary:
            //      Overridable function to create tree node.
            // args: Object
            //      Tree node creation arguments
            // tags:
            //      extension

            var node = new _DiscountTreeNode(args);
            this.own(node, node.on("nodeSelectChanged", lang.hitch(this, function () {
                this._onNodeSelectChanged(node);
            })));

            return node;
        }
    });

});