﻿define("epi-ecf-ui/widget/viewmodel/DiscountListModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/json",
    "dojo/Stateful",
    "dojo/when",
// dojox
    "dojox/mvc/StatefulArray",
// EPi Framework
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "./_MarketingListBaseModel",
// resources
    "epi/i18n!epi/nls/episerver.shared"
], function (
// dojo
    array,
    declare,
    lang,
    json,
    Stateful,
    when,
// dojox
    StatefulArray,
// EPi Framework
    dependency,
    _Command,
    TypeDescriptorManager,
// epi-cms
    ContentReference,
// epi-ecf-ui
    _MarketingListBaseModel,
// resources
    sharedResources
) {
    return declare([_MarketingListBaseModel, Stateful], {
        // summary:
        //    Represents the discount list widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/DiscountListModel"
        // tags:
        //    public

        _promotionDataStore: null,

        // items: dojox/StatefulArray
        //      The item models array
        items: null,

        // priorityStep: int
        //    The default step of priorities. We want to stretch distance between discount priority values, default is 100,
        //    whichs is retrieved from the MarketingRepositoryDescriptor.
        //    When doing reorder, we have enough room to set new priority values without affecting the other ones.
        //    This can help decrease the number of changes.
        priorityStep: null,

        // hasPendingChanges: Boolean
        //    Holds an indication if the widget's model has modified
        hasPendingChanges: false,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // tags:
            //      protected

            this.inherited(arguments);
            this._setupCommands();

            var registry = dependency.resolve("epi.storeregistry");
            this._promotionDataStore = this._promotionDataStore || registry.get("epi.commerce.promotions");

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.priorityStep = this.priorityStep || contentRepositoryDescriptors.marketing.priorityStep;
        },

        _getStatusModel: function (item) {
            var validFrom = new Date(item.properties.effectiveValidFrom);
            var validUntil = new Date(item.properties.effectiveValidUntil);

            return {
                statusLabelKey: this._getStatus(item),
                validFrom: validFrom,
                validUntil: validUntil
            };
        },

        save: function () {
            // summary:
            //      Summit priority data.
            // tags:
            //      Protected

            // save modified item only
            var promotions = array.filter(this.items, function (item) {
                return item.hasPendingChanges;
            });
            // construct patch model
            promotions = array.map(promotions, function (item) {
                return {
                    id: item.contentLink,
                    properties: {
                        priority: item.properties.priority,
                        excludedItems: json.toJson(item.properties.excludedItems)
                    }
                };
            });

            var def = this._promotionDataStore.patch({ promotions: promotions }, {});

            // update hasPendingChanges value for saved content, to make sure we will not save them again if it does not change.
            when(def).then(lang.hitch(this, function (results) {
                array.forEach(results, function (result) {
                    if (result.successful) {
                        // use array.some in order to be able to break the loop
                        array.some(this.items, function (item) {
                            if(ContentReference.compareIgnoreVersion(result.savedContentLink, item.contentLink)) {
                                item.hasPendingChanges = false;
                                return true; // break;
                            }
                        });
                    }

                }, this);
            }));

            return def;
        },

        _itemsSetter: function (value) {
            // summary:
            //      Sets items stateful array
            // tags:
            //      Private

            var i = 1;
            array.forEach(value, function (item) {
                item.order = i++;                
            });

            this.items = new StatefulArray(!value ? [] : !lang.isArray(value) ? [value] : value);
        },

        moveItem: function (fromIndex, refItem, before) {
            // summary:
            //      Move an item.
            // fromIndex: int
            //      The current index of item
            // refItem: Object
            //      The reference item, move to
            // before: Boolean
            //      Indicates that the new item should be moved before the reference index.
            // tags:
            //      Public

            var item = this.items[fromIndex];
            // remove item first
            this.items.splice(fromIndex, 1);

            // try get the index of reference item, after removed the item
            var toIndex = this.items.indexOf(refItem);
            toIndex = before ? toIndex : toIndex + 1;

            // then re-add item to new index
            this.items.splice(toIndex, 0, item);

            // If moving the item in the same place, should not have changes.
            if (fromIndex === toIndex) {
                return;
            }

            this._normalizePriorityValue(toIndex, true);
            this.set("items", this.items);
            this.set("hasPendingChanges", true);
        },

        _normalizePriorityValue: function (startIndex, isManualMove) {
            // summary:
            //      Normalize priority values for the specific startIndex, and return the priority value (it can be updated if needed).
            // startIndex: int
            //      The start index of algorithm
            // isManualMove: bool
            //      Indicated that item is moving manually.
            // tags:
            //      Private

            var startItem = this.items[isManualMove && startIndex !== 0 ? startIndex - 1 : startIndex];

            if (!startItem) {
                return;
            }

            var currentPriority = startIndex === 0 ? 0 : startItem.properties.priority,
                nextIndex = startIndex + 1;
            
            if (this.items[nextIndex]) {
                var nextPriority = this.items[nextIndex].properties.priority;

                if (nextPriority <= currentPriority + 1) {
                    // next item(s) need to be adjusted
                    nextPriority = this._normalizePriorityValue(nextIndex, false);
                }

                var midValue = Math.round((currentPriority + nextPriority) / 2);

                return this._setPriority(startIndex, midValue);
            } else {
                // this is the last item and need to be adjusted                    
                return this._setPriority(startIndex, currentPriority + this.priorityStep);
            }               
        },

        _setPriority: function(index, priority) {
            // summary:
            //      Set the priority value for item at the specific index.
            // index: int
            //      The index of item to set priority
            // priority: int
            //      The priority value
            // tags:
            //      Private
            if (!this.items[index] || !this.items[index].properties) {
                return;
            }

            this.items[index].properties.priority = priority;
            this.items[index].hasPendingChanges = true;

            return priority;
        },

        updateExcludedItem: function (item) {
            var any = array.some(this.items, function (i) {
                if(ContentReference.compareIgnoreVersion(i.contentLink, item.contentLink)) {
                    i.properties.excludedItems = item.properties.excludedItems;
                    i.hasPendingChanges = true;
                    return true;
                }
            });

            if (!any) {
                return;
            }

            this.set("hasPendingChanges", true);
        },

        _setupCommands: function () {
            // summary:
            //      Setup commands for context menu.
            // tags:
            //      Private

            // Reset commands list.
            this.commands.length = 0;

            // Move up command
            this._createMoveCommand({
                iconClass: "epi-iconUp",
                label: sharedResources.action.moveup
            }, true);

            // Move down command
            this._createMoveCommand({
                iconClass: "epi-iconDown",
                label: sharedResources.action.movedown
            }, false);
        },

        _createMoveCommand: function (settings, isMoveUp) {
            // summary:
            //      Prepare move command for context menu.
            // settings: Object
            //      Settings of the command
            // isMoveUp: bool
            //      Indicated that the command is moving up
            // tags:
            //      Private

            var self = this,
                command = new _Command({
                    category: "context",
                    iconClass: settings.iconClass,
                    label: settings.label,
                    _onModelChange: function () {
                        var rowId = this.model.currentRowId;
                        // first item can't move up
                        // last item can't move down
                        this.set("canExecute", !!this.get("model") && (isMoveUp ? rowId !== 0 : rowId < self.items.length - 1));
                    },
                    _execute: function () {
                        var rowId = this.model.currentRowId;
                        // move up : to before previous item
                        // move down : to after next item
                        self.moveItem(rowId, isMoveUp ? self.items[rowId - 1] : self.items[rowId + 1], isMoveUp);
                    }
            });

            this.commands.push(command);
        }
    });
});
