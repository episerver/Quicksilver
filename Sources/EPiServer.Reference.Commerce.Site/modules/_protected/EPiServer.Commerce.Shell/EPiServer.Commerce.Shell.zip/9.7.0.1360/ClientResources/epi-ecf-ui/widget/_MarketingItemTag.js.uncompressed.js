require({cache:{
'url:epi-ecf-ui/widget/templates/_MarketingItemTag.html':"<div class=\"dijitReset dijitLeft dijitInputField dijitInputContainer epi-categoryButton\">\n    <div class=\"dijitInline epi-resourceName\">\n        <div data-dojo-attach-point=\"textNode\" class=\"epi-textbox-tag__item dojoxEllipsis\"></div>\n        <div class=\"epi-removeButton\" data-dojo-attach-event=\"onclick:_onClick\"></div>\n    </div>\n</div>"}});
define("epi-ecf-ui/widget/_MarketingItemTag", [
// dojo
    "dojo/_base/declare",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/Tooltip",

// epi
    "epi/shell/dgrid/util/misc",

// epi-ecf-ui
    "../MarketingUtils",

// resources
    "dojo/text!./templates/_MarketingItemTag.html"
],

function (
// dojo
    declare,

// dijit
    _TemplatedMixin,
    _WidgetBase,
    Tooltip,

// epi
    shellMisc,

// epi-ecf-ui
    MarketingUtils,

// resources
    template
) {

    return declare([_WidgetBase, _TemplatedMixin], {
        // summary:
        //      A widget represents a button tag of an marketing item.
        // tags:
        //      internal

        templateString: template,
        
        item : null,

        postCreate : function () {
            // summary:
            //      Set text for the button tag.
            // tags:
            //      protected

            this.inherited(arguments);

            if(this.item !== null) {
                this.textNode.innerHTML = shellMisc.htmlEncode(this.item.name);
                new Tooltip({
                    connectId: this.textNode,
                    label: this._getItemPath()
                });
            }
        },

        _onClick : function () {
            this.onRemoveClick(this.item.contentLink);
        },

        _getItemPath: function () {
            // summary:
            //    Return the path to a campaign/promotion excluding root.
            // item:
            //    the marketing item (campaign/promotion)
            // tags:
            //    private

            if (MarketingUtils.isPromotionData(this.item.typeIdentifier)) {
                return shellMisc.htmlEncode(this.item.properties.campaignName + ' / ' + this.item.name);
            }

            return shellMisc.htmlEncode(this.item.name);
        },

        onRemoveClick : function (contentLink) {
            //summary:
            //    Handle the remove button click
            // tags:
            //    protected
        }
    });
});