﻿define("epi-ecf-ui/component/DeleteCatalogContentHandler", [
    //Dojo
        "dojo/_base/declare",
        "dojo/_base/json",
        "dojo/_base/lang",
        "dojo/Deferred",
        "dojo/topic",
    //Epi
        "epi/string",
        "epi/shell/widget/dialog/Alert",
    //Epi ecf
        "./DeleteConfirmation"
], function (
    //Dojo
        declare,
        json,
        lang,
        Deferred,
        topic,
    //Epi
        epiString,
        Alert,
    //Epi ecf
        DeleteConfirmation
) {
     //summary:
     //     Adds confirmation before executing delete command and hide dialog after delete is done.

    var handler = function (settings) {

        var deferred = new Deferred(),
            dialog = new DeleteConfirmation(lang.mixin(settings, { destroyOnHide: true }));

        dialog.connect(dialog, "onAction", function (confirm) {
            if (confirm) {
                deferred.resolve();
            } else {
                deferred.cancel();
                okHandler.remove();
                errorHandler.remove();
            }
        });

        dialog.show();

        var okHandler = topic.subscribe("catalogContentDeleted", function () {
            dialog.hide();
            okHandler.remove();
        });
        var errorHandler = topic.subscribe("/epi/cms/action/delete/error", function (errorResponse) {
            dialog.hide();
            var message = json.fromJson(errorResponse.xhr.responseText)[0].errorMessage;

            var alertDialog = new Alert({
                description: epiString.toHTML(message),
                destroyOnHide: true
            });

            alertDialog.show();
            errorHandler.remove();
        });

        return deferred;
    };

    return handler;
});