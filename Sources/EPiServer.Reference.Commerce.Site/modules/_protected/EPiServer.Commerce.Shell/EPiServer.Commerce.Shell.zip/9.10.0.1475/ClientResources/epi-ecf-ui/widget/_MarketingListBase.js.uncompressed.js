require({cache:{
'url:epi-ecf-ui/widget/templates/_MarketingListBase.html':"﻿<div>\n    <!-- the toolbar is only here to be able to resize without exceptions -->\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"dijit/_WidgetBase\" style=\"display:none\"></div>\n    <div data-dojo-attach-point=\"gridNode\"></div>\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignNameColumn.html':"﻿<div>\n    <h1>${name}</h1>\n    <h2>${group}</h2>\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignOrdersColumn.html':"﻿<h1>${nrOfOrders}</h1>\n<h2>${text}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/CampaignStatusColumn.html':"﻿<h1>${statusLabel}</h1>\n<h2>${fromDate} - ${toDate}</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionNameColumn.html':"﻿<h3>${name}</h3>\n<span class=\"dijitInline dijitReset dijitIcon epi-objectIcon ${iconClass}\"></span> <span class=\"epi-secondaryText\">${group}</span>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionOrdersColumn.html':"﻿<h2>\n    <h3>${nrOfOrders}</h3>\n    <span class=\"epi-secondaryText\">${text}</span>\n</h2>",
'url:epi-ecf-ui/widget/viewmodel/templates/PromotionStatusColumn.html':"﻿<div class=\"epi-grid-column--centered\">\n    ${text} ${date}\n</div>",
'url:epi-ecf-ui/widget/viewmodel/templates/RedeemedValueColumn.html':"﻿<h1>${redeemedValueAmount}</h1>\n<h2>${redeemedValue}</h2>"}});
﻿define("epi-ecf-ui/widget/_MarketingListBase", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/string",
    "dojo/when",
// dijit
    "dgrid/tree",
// epi
    "epi/datetime",
    "epi/shell/dgrid/util/misc",
    "epi/shell/TypeDescriptorManager",
// epi-cms
    "epi-cms/widget/_ConfigurableContentListBase",
// epi-ecf-ui
    "../MarketingUtils",
    "./_GridRowStatusMixin",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "dojo/text!./templates/_MarketingListBase.html",
    "dojo/text!./viewmodel/templates/CampaignNameColumn.html",
    "dojo/text!./viewmodel/templates/CampaignOrdersColumn.html",
    "dojo/text!./viewmodel/templates/CampaignStatusColumn.html",
    "dojo/text!./viewmodel/templates/PromotionNameColumn.html",
    "dojo/text!./viewmodel/templates/PromotionOrdersColumn.html",
    "dojo/text!./viewmodel/templates/PromotionStatusColumn.html",
    "dojo/text!./viewmodel/templates/RedeemedValueColumn.html"
], function (
// dojo
    declare,
    lang,
    domClass,
    domConstruct,
    dojoString,
    when,
//dijit
    tree,
// epi
    epiDate,
    shellMisc,
    TypeDescriptorManager,
// epi-cms
    _ConfigurableContentListBase,
// epi-ecf-ui
    MarketingUtils,
    _GridRowStatusMixin,
// resources
    resources,
    templateString,
    campaignNameColumnTemplate,
    campaignOrdersColumnTemplate,
    campaignStatusColumnTemplate,
    promotionNameColumnTemplate,
    promotionOrdersColumnTemplate,
    promotionStatusColumnTemplate,
    redeemedValueColumnTemplate
) {
    return declare([_ConfigurableContentListBase, _GridRowStatusMixin], {
        // summary:
        //      Represents the widget to support to styling a grid to display marketing item
        // tags:
        //      public

        templateString: templateString,

        storeKeyName: "epi.cms.content.light",

        // queryName: string
        //      Default query is get children
        queryName: "getchildren",

        _campaignClassName: "epi-card-grid__heading",
        _promotionClassName: "epi-card-grid__content",

        // itemType: Object
        //      Types used on marketing objects
        itemType: {
            notSet: 0,
            promotion: 1,
            campaign: 2
        },

        _getQuery: function (parentId) {
            return {
                query: this.queryName,
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers
            };
        },

        startup: function () {
            this.inherited(arguments);

            when(this.getCurrentContext()).then(lang.hitch(this, function (currentContext) {
                this.grid.set("query", this._getQuery(currentContext.id));
            }));
        },

        onContextChanged: function (context) {
            // Refresh list after edit
            this.grid.set("query", this._getQuery(context.id));
        },

        getListSettings: function () {
            var settings = this.inherited(arguments);

            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                className: "epi-card-grid",
                store: this.store,
                selectionMode: "none",
                cellNavigation: false,
                noDataMessage: resources.emptycampaign
            }));
        },

        getItemType: function (typeIdentifier) {
            if (MarketingUtils.isSalesCampaign(typeIdentifier)) {
                return this.itemType.campaign;
            }
            if (MarketingUtils.isPromotionData(typeIdentifier)) {
                return this.itemType.promotion;
            }
            return this.itemType.notSet;
        },

        getItemClass: function (item) {
            //  Override mixin class

            if (this.getItemType(item.typeIdentifier) === this.itemType.campaign) {
                return this._campaignClassName;
            } else {
                return this._promotionClassName;
            }
        },

        getItemModifier: function (item) {
            if (item.properties.status === MarketingUtils.status.expired) {
                return this.getItemType(item.typeIdentifier) === this.itemType.campaign ?
                            this.status[MarketingUtils.status.expired] :
                            this.status[MarketingUtils.status.inactive];
            } else {
                return this.inherited(arguments);
            }
        },

        getColumnSettings: function(){
            return {
                expando: tree({
                    label: "",
                    sortable: false,
                    shouldExpand: function () { return true; },
                    renderExpando: function (level, hasChildren, expanded, object) {
                        // summary:
                        //      We override the default expando rendering to get rid of the
                        //      default indentation.

                        var node = domConstruct.create("div");
                        //"dgrid-expando-icon" is needed for click events
                        domClass.add(node, "dgrid-expando-icon");
                        node.innerHTML = "&nbsp;";
                        return node;
                    }
                }),
                name: {
                    className: "epi-grid--40",
                    get: lang.hitch(this.model, this.model._getNameModel),
                    formatter: lang.hitch(this, this._getNameHtml)
                },
                status: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this.model, this.model._getStatusModel),
                    formatter: lang.hitch(this, this._getStatusHtml)
                },
                orders: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { typeIdentifier: campaignItem.typeIdentifier, orders: campaignItem.properties.redemptions };
                    },
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = "&nbsp;"; //TODO: Add column value when is implemented on the server;
                    })
                },
                revenue: {
                    className: "epi-grid--15",
                    get: function (campaignItem) {
                        return { typeIdentifier: campaignItem.typeIdentifier, revenue: campaignItem.properties.redeemedValue };
                    },
                    renderCell: lang.hitch(this, function (item, value, node, options) {
                        domClass.add(node, "epi-grid-column--centered");
                        node.innerHTML = "&nbsp;"; //TODO: Add column value when is implemented on the server
                    })
                }
            };
        },

        _getStatusHtml: function (statusColumnModel) {
            if (this.getItemType(statusColumnModel.typeIdentifier) === this.itemType.campaign) {
                return dojoString.substitute(campaignStatusColumnTemplate, {
                    statusLabel: resources.status[statusColumnModel.statusLabelKey],
                    fromDate: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true),
                    toDate: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            var promotionStatus = statusColumnModel.status;
            var campaignStatus = statusColumnModel.campaignStatus;

            if (promotionStatus === MarketingUtils.status.inactive) {
                return resources.status.inactive;
            }

            if (statusColumnModel.followsCampaignSchedule || campaignStatus === MarketingUtils.status.expired || campaignStatus === MarketingUtils.status.inactive) {
                return "";
            }

            if (promotionStatus === MarketingUtils.status.active) {
                return dojoString.substitute(promotionStatusColumnTemplate, {
                    text: epiDate.toUserFriendlyString(statusColumnModel.validFrom, null, null, true) + " -",
                    date: epiDate.toUserFriendlyString(statusColumnModel.validUntil, null, null, true)
                });
            }

            return dojoString.substitute(promotionStatusColumnTemplate, {
                date: epiDate.toUserFriendlyString(this._getDate(statusColumnModel), null, null, true),
                text: this._getDateText(statusColumnModel)
            });
        },

        _getDate: function (statusColumnModel) {

            if (statusColumnModel.validFrom > new Date()) {
                return statusColumnModel.validFrom;
            }

            return statusColumnModel.validUntil;
        },

        _getDateText: function (statusColumnModel) {
            var validFrom = statusColumnModel.validFrom,
                validUntil = statusColumnModel.validUntil,
                now = new Date();

            if (validFrom < now && validUntil > now) { // Currently active
                return resources.datetext.active;
            }

            if (validFrom > now) { // Pending
                return resources.datetext.pending;
            }

            return resources.datetext.expired; // Expired
        },

        _getNameHtml: function (nameColumnModel) {
            var template = promotionNameColumnTemplate;

            if (this.getItemType(nameColumnModel.typeIdentifier) === this.itemType.campaign) {
                template = campaignNameColumnTemplate;
            }

            return dojoString.substitute(template, {
                name: shellMisc.htmlEncode(nameColumnModel.name),
                group: (!!nameColumnModel.group) ? resources.group[nameColumnModel.group] : resources.campaign,
                iconClass: TypeDescriptorManager.getValue(nameColumnModel.typeIdentifier, "iconClass")
            });
        }
    });
});