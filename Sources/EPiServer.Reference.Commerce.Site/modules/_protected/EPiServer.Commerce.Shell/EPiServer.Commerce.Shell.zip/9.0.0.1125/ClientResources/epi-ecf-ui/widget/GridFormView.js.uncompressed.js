require({cache:{
'url:epi-ecf-ui/widget/templates/GridFormView.html':"﻿﻿<div>\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\n    <div data-dojo-attach-point=\"formContainer\"></div>\n</div>"}});
﻿define("epi-ecf-ui/widget/GridFormView", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/topic",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/shell/TypeDescriptorManager",
    "epi/shell/ViewSettings",
// epi-cms
    "epi-cms/contentediting/_FormEditingMixin",
    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/contentediting/MappingManager",
// epi-ecf-ui
    "./MarketingToolbar",
    "../contentediting/ModelSupport",
// resources
    "dojo/text!./templates/GridFormView.html",
    "epi/i18n!epi/nls/episerver.shared",
    "epi/i18n!epi/cms/nls/commerce.widget.gridformview"
], function (
// dojo
    declare,
    lang,
    aspect,
    domClass,
    domGeometry,
    topic,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    TypeDescriptorManager,
    ViewSettings,
// epi-cms
    _FormEditingMixin,
    ContentViewModel,
    MappingManager,
// epi-ecf-ui
    MarketingToolbar,
    ModelSupport,
// resources
    template,
    sharedResources,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _FormEditingMixin], {
        // tags:
        //      internal

        templateString: template,

        editLayoutContainer: {}, /* required object for _FormEditingMixin */

        _buttonNames: {
            saveButton: "saveButton",
            closeButton: "closeButton"
        },

        _contextChangeStrings: [
            "/epi/shell/context/request",
            "/epi/shell/action/changeview",
            "/epi/shell/action/changeview/back"
        ],

        postCreate: function () {
            this.inherited(arguments);
            this._setupToolbar();
            this.formSettings = {
                baseClass: "epi-grid-form"
            };
            this._mappingManager = new MappingManager();
            this.own(aspect.around(topic, "publish", lang.hitch(this, "_aroundTopicPublish")));
            window.onbeforeunload = lang.hitch(this, "_onBeforeUnload");
        },

        _setupToolbar: function(){
            var buttons = [{
                parent: this.toolbar.groupNames.trailing,
                name: this._buttonNames.saveButton,
                title: sharedResources.action.save,
                label: sharedResources.action.save,
                type: "button",
                action: lang.hitch(this, this._onSave),
                settings: {
                    "class": "epi-button--bold",
                    disabled: true
                }
            },
            {
                parent: this.toolbar.groupNames.trailing,
                name: this._buttonNames.closeButton,
                title: sharedResources.action.close,
                label: sharedResources.action.close,
                type: "button",
                action: lang.hitch(this, this._onCancel),
                settings: { "class": "epi-button--bold" }
            }];
            this.toolbar.add(buttons);
        },

        _onSave: function(){
            if (this.viewModel){
                this.viewModel.save();
            }
        },

        _onCancel: function () {
            // Go back to the campaign overview list
            topic.publish("/epi/shell/context/request", { uri: ViewSettings.settings.defaultContext }, { sender: this });
        },

        _aroundTopicPublish: function (original) {
            return lang.hitch(this, function(item) {
                if (!this._isContextChangeRequest(item)) {
                    return original.apply(topic, arguments);
                }

                if (this._changesSaved() || this._confirmDiscardChanges())
                {
                    //we need to reset the hasPendingChange value here regardless of what it was before
                    //otherwise the confirmbox will always appear
                    this.viewModel.set("hasPendingChanges", false);
                    return original.apply(topic, arguments);
                }
            });
        },

        _isContextChangeRequest: function(requestString){
            return requestString && this._contextChangeStrings.indexOf(requestString) >= 0;
        },

        _changesSaved: function() {
            return !this.viewModel.get("hasPendingChanges");
        },

        _confirmDiscardChanges: function() {
            return window.confirm(resources.warnunsavedchanges + " " + resources.confirmdiscarchanges);
        },

        _onBeforeUnload: function() {
            if (!this._changesSaved()) {
                return resources.warnunsavedchanges;
            }
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this.toolbar.update({
                currentContext: context
            });

            if (this.viewModel){
                this.viewModel.validator.clearErrorsBySource(this.viewModel.validator.validationSource.client);
                this.viewModel.validator.clearErrorsBySource(this.viewModel.validator.validationSource.server);
                this.viewModel.destroy();
            }
            this.viewModel = this._createViewModel(context.id);
            this.own(this.viewModel);
            return this.viewModel.reload().then(lang.hitch(this, function(){
                this.onReadySetupEditMode();
                this.viewModel.own(this.viewModel.watch("hasPendingChanges", lang.hitch(this,
                    function (property, oldValue, newValue) {
                        this.toolbar.setItemProperty(this._buttonNames.saveButton, "class", "epi-button--bold" + (newValue ? " epi-primary" : ""));
                        this.toolbar.setItemProperty(this._buttonNames.saveButton, "disabled", !newValue);
                })));
            }));
        },

        _createViewModel: function(contentLink){
            return new ContentViewModel({
                contentLink: contentLink,
                local: true,
                contextTypeName: "epi.cms.contentdata",
                /* BEGIN HACK FOR BUG #129812 */
                _commitChanges: function (/*Array*/ properties) {
                    // summary:
                    //      This code is copied from episerver-ui repo and modified to remove the call to save:
                    // https://stash.ep.se/projects/SH/repos/episerver-ui/browse/EPiServer.Cms.Shell.UI/UI/ClientResources/epi-cms/contentediting/ContentViewModel.js?until=40a2125204c7427610c0df08490368864d714439#303

                    var inverseProperties = [];

                    properties.forEach(function (property) {
                        inverseProperties.push({
                            propertyName: property.propertyName,
                            value: property.oldValue,
                            oldValue: property.value
                        });
                        this.syncService.scheduleForSync(property.propertyName, property.value);
                    }, this);

                    this.undoManager.createStep(this, this._saveProperties, [inverseProperties], 'Edit properties');

                    // the commented line below is the change from the original code. We don't want to save here.
                    // this.save();
                }
                /* END HACK FOR BUG #129812 */
            });
        },

        placeForm: function(form){
            form.placeAt(this.formContainer);
            this.layout();
        },

        removeForm: function(form){
            return true;
        },

        _onWrapperValueChange: function (wrapper, value, oldValue) {
            var mapping = this._mappingManager.findOne("wrapper", wrapper),
                propertyName = mapping.propertyName;

            this.viewModel.setProperty(propertyName, value, oldValue);
        },

        _onWrapperStopEdit: function (wrapper, value, oldValue, implicitExit) {
            // _FormEditingMixin required property
        },

        _onWrapperCancel: function (wrapper, implicitExit) {
            // _FormEditingMixin required property
        },

        onSetupEditModeComplete: function(){
            // _FormEditingMixin required property
            if (this._typeIsAssignableFrom(this.viewModel.contentData.typeIdentifier, ModelSupport.contentTypeIdentifier.salesCampaign)) {
                this._form.containerLayout.set("header", resources.campaignformheading);
            } else {
                this._form.containerLayout.set("header", resources.discountformheading);
            }
            this._currentGroup = null;
        },

        onGroupCreated: function(groupName, widget, parentGroupWidget) {
            this.inherited(arguments);
            this._currentGroup = widget;
        },

        onFieldCreated: function(fieldName, widget) {
            this.inherited(arguments);
            this._resizeNameField(fieldName, widget);
            this._resizeWidget(widget);
        },

        _resizeNameField: function (fieldName, widget) {
            // summary:
            //      Add the css class epi-input--full-width to the name field
            //      in order to make it as wide as a long string property
            // tags:
            //      internal

            if (fieldName === "icontent_name") {
                domClass.add(widget.domNode, "epi-input--full-width");
            }
        },

        _resizeWidget: function(widget){
            // summary:
            //      This makes sure that some editors that define width
            //      in code (XHtml and Longstring properties) does not
            //      become to wide
            // tags:
            //      internal

            var fullWidthParent = this._currentGroup ? this._currentGroup.hasOwnRow : true;
            if (fullWidthParent){
                return;
            }
            /*  this will fix widgets that sets a width property.
                IE TinyMCEEditors for xhtml strings */
            if (widget.width > 470){
                widget.set("width", 470);
            }
            /*  this is a special case for PropertyLongstring
                that is needed because it hardcodes it's style
                to be width:582px; to match xhtml strings :'(
                see: https://stash.ep.se/projects/SH/repos/episerver-ui/browse/EPiServer.Cms.Shell.UI/UI/ObjectEditing/EditorDescriptors/LongStringEditorDescriptor.cs?until=1df13a6315b120175b5755814ae2f280ec519d38#24
            */
            if (widget.style === "width:582px;"){
                widget.set("style", "width:472px;");
            }
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            if (this._form){
                var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);

                // Set the size of the form to be the content height minus the toolbar height.
                this._form.resize({
                    h: this._contentBox.h - toolbarSize.h,
                    w: this._contentBox.w
                });
            }
        },

        _typeIsAssignableFrom: function (/*string*/ type, /*string*/ baseTypeToSupport) {
            return TypeDescriptorManager.isBaseTypeIdentifier(type, baseTypeToSupport);
        }
    });
});