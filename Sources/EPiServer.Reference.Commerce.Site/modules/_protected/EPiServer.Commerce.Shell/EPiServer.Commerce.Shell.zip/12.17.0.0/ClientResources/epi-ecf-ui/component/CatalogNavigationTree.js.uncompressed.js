﻿define("epi-ecf-ui/component/CatalogNavigationTree", [
// dojo
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",
// epi
    "epi-cms/component/ContentNavigationTree",
// commerce
    "../widget/viewmodel/CatalogTreeStoreModel",
    "./ContentContextMenuCommandProvider",
    "./commerceDndSource"
],

function (
// dojo
    declare,
    Deferred,
    when,
// epi
    ContentNavigationTree,
// commerce
    CatalogTreeStoreModel,
    ContextMenuCommandProvider,
    commerceDndSource
 ) {

    // module:
    //      epi-ecf-ui.component.CatalogNavigationTree

    return declare([ContentNavigationTree], {
        // summary:
        //      Catalog tree component, which support market filtering.
        // tags:
        //      public

        dndSource: commerceDndSource,

        contextMenuCommandProvider: ContextMenuCommandProvider,

        _createTreeModel: function () {
            // summary:
            //      Create content tree model
            // tags:
            //      protected override

            return new CatalogTreeStoreModel({
                roots: this.roots,
                typeIdentifiers: this.typeIdentifiers,
                containedTypes: this.settings.containedTypes
            });
        },

        // Remark: Because cms-ui starts to use confirm on pasteItems and not just pasteItem
        _wrapModel: function (model) {
            return model;
        },

        _updateGlobalToolbarButtons: function (targetNode) {

            if (targetNode){
                var parent = targetNode.getParent();

                targetNode.item.contextId = parent.dndData.contentLink;
            }

            this.inherited(arguments);
        },

        selectContent: function (contentReferenceAsString, setFocus, needParentRefresh, onComplete) {
            // summary:
            //      Select a given content.
            // tags:
            //      public override

            var args = arguments,
                inherited = this.getInherited(args),
                deferred = new Deferred();

            return when(this.model.store.get(contentReferenceAsString), function (content) {
                if (content && !content.properties.isLinkedToCurrentCategory) {
                    return inherited.apply(this, args);
                }

                return deferred.promise;
            }.bind(this));
        }
    });

});