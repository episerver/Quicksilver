//>>built
define("epi-ecf-ui/patch/patches",["./epi-cms/contentediting/StandardToolbar"],function(){return {};});