﻿define("epi-ecf-ui/contentediting/viewmodel/InventoryOverviewEditorModel", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",

    // dojox
    "dojox/html/entities",

    // epi
    "epi/shell/command/DelegateCommand",
    "epi/datetime",
    "epi-cms/dgrid/formatters",

    // commerce
    "./_OverviewEditorModelBase",

    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    //dojo
    array,
    declare,
    lang,
    all,

    // dojox
    htmlEntities,

    // epi
    DelegateCommand,
    epiDate,
    formatters,

    // commerce
    _OverviewEditorModelBase,

    // resources
    resources,
    res
) {
    return declare([_OverviewEditorModelBase], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/InventoryOverviewEditorModel
        // summary:
        //      Represents the model for InventoryOverviewEditor

        _storeKey: "epi.commerce.inventory",

        _createQueryOptions: function () {
            // summary:
            //      Creates and returns query options, based on selected content link, market id and customer group (if any).
            // tags:
            //      private

            return {
                query: { referenceId: this.get("contentLink"), query: "getinventory" }
            };
        },

        getCommands: function (model, category) {
            return [
                new DelegateCommand({
                    name: "remove",
                    label: resources.commands.remove,
                    iconClass: "epi-iconClose",
                    category: category,
                    model: model,
                    canExecute: true,
                    isAvailable: true,
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("removeCommandEvent");
                    })
                })
            ];
        },

        removeItems: function (models) {
            var promises = [];

            for (var i = 0, j = models.length; i < j; i += 1) {
                promises.push(this.store.remove(models[i].contentLink + "$" + models[i].warehouseCode));
            }

            return all(promises).then(lang.hitch(this, function (removed) {
                this.emit("itemsRemoved", { removedItems: removed });
            }));
        },

        generateFormatters: function (columnDefinitions, editableColumns, metadata) {
            for (var definitionName in columnDefinitions) {
                var column = columnDefinitions[definitionName];

                if (definitionName === "warehouseCode") {
                    column.formatter = this._getWarehouseFormatter(metadata);
                    continue;
                }

                if (!this._isColumnEditable(definitionName, editableColumns)) {
                    continue;
                }

                if (definitionName === "backorderAvailableUtc" || definitionName === "preorderAvailableUtc" || definitionName === "purchaseAvailableUtc") {
                    column.formatter = formatters.localizedDate;
                } else if (definitionName === "isTracked") {
                    column.formatter = formatters.friendlyBoolean;
                } else if (column.editorArgs && column.editorArgs.selections && column.editorArgs.selections.length > 0) {
                    column.formatter = this._getSelectionFormatter(column);
                } else {
                    column.formatter = this._editableValueFormatter;
                }

                column.className = column.className ? column.className + " epi-dgrid--editable" : "epi-dgrid--editable";
            }
        },

        getAllItems: function (contentLink) {
            return this.store.query({ referenceId: contentLink });
        },

        _getWarehouseFormatter: function (metadata) {
            // summary:
            //      A custom formatter for the warehouse code. Display the selection for the current value, but don't make the field editable.

            var selections;
            array.some(metadata.properties, function (property) {
                if (property.name === "WarehouseCode") {
                    selections = property.selections;
                    return true;
                }
            });

            return lang.hitch(this, function (value) {
                array.some(selections, function (selection) {
                    if (selection.value === value) {
                        value = selection.text;
                        return true;
                    }
                });
                return value;
            });
        }
    });
});