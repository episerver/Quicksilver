﻿define("epi-ecf-ui/contentediting/viewmodel/_OverviewEditorModelBase", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Evented",
    "dojo/Stateful",
    "dojo/when",

    // epi
    "epi/dependency",
    "epi/string"
],
function (
    //dojo
    array,
    declare,
    lang,
    Evented,
    Stateful,
    when,

    // epi
    dependency,
    epiString
) {
    return declare([Stateful, Evented], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/_OverviewEditorModelBase
        // summary:
        //      Base class for InventoryOverviewEditorModel and PricingOverviewEditorModel

        metadataManager: null,

        store: null,

        postscript: function () {
            this.inherited(arguments);

            this.storeRegistry = dependency.resolve("epi.storeregistry");
            this.store = this.store || this.storeRegistry.get(this._storeKey);

            this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
        },

        addItem: function (item) {
            return when(this.store.add(item), lang.hitch(this, function (data) {
                this.emit("itemAdded", { id: data.id });
            }));
        },

        _isColumnEditable: function (columnName, editableColumns) {
            return array.some(editableColumns, function (editableColumn) {
                return epiString.pascalToCamel(editableColumn) === columnName;
            });
        },

        _editableValueFormatter: function (value) {
            return '<span class="epi-dgrid--editable__content">' + value + '</span>';
        },

        _getSelectionFormatter: function (column) {
            // summary:
            //      On widgets with selections we need to display the text of the selection instead of the value.

            return lang.hitch(this, function (value) {
                array.some(column.editorArgs.selections, function (selection) {
                    if (selection.value === value) {
                        value = selection.text;
                        return true;
                    }
                });
                return this._editableValueFormatter(value);
            });
        }
    });
});