﻿define("epi-ecf-ui/patch/epi-cms/contentediting/StandardToolbar", [
// dojo
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi/dependency",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/StandardToolbar"
], function (
// dojo
    lang,
    when,
// epi
    dependency,
    ContentActionSupport,
    StandardToolbar
) {

    // module:
    //      patch/epi-cms/contentediting/StandardToolbar
    // summary:
    //      Filters out un-authorized views based on the current content and its access rights.

    var base = StandardToolbar.prototype.updateChildren;

    lang.mixin(StandardToolbar.prototype, {
        updateChildren: function () {
            base.apply(this, arguments);

            if (!this.currentContext) {
                return;
            }

            this._store = this._store || dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
            when(this._store.get(this.currentContext.id)).then(function (content) {
                var hasAccess = ContentActionSupport.hasAccess(content.accessMask, ContentActionSupport.accessLevel.Read | ContentActionSupport.accessLevel.Publish);
                if (!hasAccess) {
                    this.viewConfigurations.availableViews = this._getAuthorizedViews(this.viewConfigurations.availableViews);
                    this.setItemProperty("viewselect", "viewConfigurations", this.viewConfigurations);
                }
            }.bind(this));
        },

        _getAuthorizedViews: function (availableViews) {
            return availableViews.filter(function (view) {
                return ["inventoryview", "linksview", "pricingview", "relatedentrieseditview", "variantview"].indexOf(view.key) === -1;
            });
        }
    });

    StandardToolbar.prototype.updateChildren.nom = "updateChildren";

});