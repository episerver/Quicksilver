﻿define("epi-ecf-ui/widget/viewmodel/CatalogTreeStoreModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/promise/all",
    "dojo/when",
    "dojo/topic",
// epi
    "epi/dependency",
    "epi/routes",
    "epi/string",
    "epi/shell/XhrWrapper",
    "epi/shell/widget/dialog/Alert",
    "epi/shell/widget/dialog/Dialog",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/ContentForestStoreModel",

// epi-ecf-ui
    "../../contentediting/ModelSupport",
    "../CatalogPasteItemDialog",
    // resources
    "epi/i18n!epi/nls/commerce.components.catalogtree"
],

function (
// dojo
    array,
    declare,
    lang,
    Deferred,
    promiseAll,
    when,
    topic,
// epi
    dependency,
    routes,
    epiString,
    XhrWrapper,
    Alert,
    Dialog,
    TypeDescriptorManager,
    ContentReference,
    ContentForestStoreModel,

// epi-ecf-ui
    ModelSupport,
    CatalogPasteItemDialog,
    resources
) {
    // module:
    //      epi-ecf-ui.widget.viewmodel.CatalogTreeStoreModel

    return declare([ContentForestStoreModel], {
        // summary:
        //      Catalogs tree store model, which support listing catalog content with market filter.
        // tags:
        //      public

        relationStore: null,

        xhrHandler: null,

        // flag to indicate whether the duplicate/move/link action is performed by DnD action from Catalog list.
        _dropFromCatalogList: false,

        typeDescriptorManager: TypeDescriptorManager,

        constructor: function () {
            this.relationStore = this.relationStore || dependency.resolve("epi.storeregistry").get("epi.commerce.relation");
            this.contentTypeStore = this.contentTypeStore || dependency.resolve("epi.storeregistry").get("epi.cms.contenttype");
            this._handles.push(topic.subscribe("relationChanged", lang.hitch(this, this._relationChanged)));
            if (!this.xhrHandler) {
                this.xhrHandler = new XhrWrapper();
            }
        },

        _relationChanged: function (addedItem) {
            this._childrenChanged(addedItem.target);
        },

        newItems: function (items, newParentItem) {
            var newItems = items.map(function (item) {
                var contextId = item.dndData.options && item.dndData.options.oldParentItem
                                    ? item.dndData.options.oldParentItem.contentLink
                                    : item.dndData.data.parentLink;
                return lang.mixin({ contextId : contextId }, item.dndData.data);
            });

            return this._selectAction(newItems, newParentItem);
        },

        pasteItems: function (sourceItems, targetItem, copy, sortIndex, actionType) {

            if (!actionType) {
                return this._selectAction(sourceItems, targetItem);
            }

            if (!sourceItems || !targetItem) { return; }

            var inherited = this.getInherited(arguments);
            switch (actionType) {
                case 'link':
                    var deferreds = sourceItems.map(function (childItem) {
                        return this._addRelation(childItem, targetItem);
                    }, this);
                    return promiseAll(deferreds);

                case 'move':
                    var itemsToMove = [];
                    var itemsToReplaceRelation = [];

                    sourceItems.forEach(function (childItem) {
                        if (ContentReference.compareIgnoreVersion(childItem.parentLink, childItem.contextId || childItem.parentLink)) {
                            itemsToMove.push(childItem);
                        } else {
                            itemsToReplaceRelation.push(childItem);
                        }
                    });

                    return this._replaceRelations(itemsToReplaceRelation, targetItem).then(function () {

                            if (!itemsToMove.length) {
                                return new Deferred().resolve([]);
                            }

                            return when(inherited.apply(this, [itemsToMove, targetItem, false, null]))
                                .then(function () {
                                    topic.publish("catalogItemsMoved");
                                });
                        }.bind(this));

                case 'duplicate':
                    return inherited.apply(this, [sourceItems, targetItem, true, null]);

                default:
                    break;
            }
        },

        _selectAction: function (items, newParentItem) {

            return this._isContentTypeAllowed(items, newParentItem).then(function (isContentTypesAllowed) {

                if (!isContentTypesAllowed) {
                    return this._showContentTypeAlert();
                }

                var isLinkSupported = this._isLinkSupported(newParentItem.typeIdentifier);

                return this._newItemConfirmation(false, !isLinkSupported).then(function (actionType) {

                    this._dropFromCatalogList = true;

                    return this.pasteItems(items, newParentItem, null, null, actionType).then(function () {
                        this._dropFromCatalogList = false;
                    }.bind(this));
                }.bind(this));
            }.bind(this));
        },

        _showContentTypeAlert: function (response) {
            // summary:
            //      Show an alert dialog if a content type can't be dropped
            // tags:
            //      protected

            if (this._invalidContentTypeAlertDialog) {
                this._invalidContentTypeAlertDialog.destroy();
            }
            var def = new Deferred();
            this.own(this._invalidContentTypeAlertDialog = new Alert({
                description: epiString.toHTML(resources.contenttypesnotallowed),
                onAction: function () {
                    def.reject();
                }
            }));

            this._invalidContentTypeAlertDialog.show();

            return def.promise;
        },

        _newItemConfirmation: function (hideMoveOption, hideLinkOption) {
            var deferred = new Deferred();

            var pasteItemDialog = new CatalogPasteItemDialog({
                hideMoveOption: hideMoveOption,
                hideLinkOption: hideLinkOption,
                executeDialog: function (actionType) {
                    deferred.resolve(actionType);
                },
                cancelDialog: function () {
                    deferred.cancel();
                }
            });

            var dialog = new Dialog({
                dialogClass: "epi-dialog-confirm",
                defaultActionsVisible: false,
                content: pasteItemDialog,
                title: pasteItemDialog.title
            });

            dialog.show();

            return deferred.promise;
        },

        _selectItemOnPasteComplete: function (item, copy, isDeleted, oldParentItem, newParentItem) {
            // summary:
            //		Select an item after a paste operation has completed. Override this function to keep current context when moving content.
            // item: Item
            //      The target item of the operation
            // copy: boolean
            //      If it was a copy operation or not
            // isDeleted: boolean
            //      If the operation resulted in the item being deleted, i.e. moved to the trash
            // oldParentItem: Item
            //      The current parent item
            // newParentItem: Item
            //      The target item for the operation
            // tags: protected, override

            if (this._dropFromCatalogList === true) {
                // keep the selected/viewing page, instead of selecting the new parent page in case of dropping item from Catalog list to Catalog tree, to make it consistent with common UX pattern.
            } else {
                // otherwise, invoke base function to select new node.
                this.inherited(arguments);
            }
        },

        _getRelations: function (contentLink) {
            return this.relationStore.query({ referenceId: contentLink });
        },

        _addRelation: function (childItem, newParentItem) {
            return this._getRelations(childItem.contentLink).then(function (relations) {
                var maxSortOrder = 0;

                relations.forEach(function (relation) {
                    if (relation.sortOrder > maxSortOrder) {
                        maxSortOrder = relation.sortOrder;
                    }
                });

                return this.relationStore.add({
                    source: childItem.contentLink,
                    target: newParentItem.contentLink,
                    type: ModelSupport.relationType.node,
                    sortOrder: maxSortOrder + 100
                }).then(function (addedItem) {
                    topic.publish("relationChanged", addedItem);
                });
            }.bind(this));
        },

        _replaceRelations: function (childItems, newParentItem) {

            var promises = childItems.map(function (childItem) {

                return this._getRelations(childItem.contentLink).then(function (relations) {

                    relations.forEach(function (oldRelation) {
                        var contextId = childItem.contextId || childItem.parentLink;

                        if (oldRelation.type !== ModelSupport.relationType.node ||
                                !ContentReference.compareIgnoreVersion(oldRelation.target, contextId)) {
                            return;
                        }

                        var newRelation = {
                            source: childItem.contentLink,
                            target: newParentItem.contentLink,
                            type: ModelSupport.relationType.node,
                            sortOrder: oldRelation.sortOrder
                        };

                        return this.relationStore.remove(oldRelation.id).then(function () {
                            return this.relationStore.add(newRelation).then(function (addedItem) {
                                topic.publish("relationChanged", addedItem);
                                this._childrenChanged(new ContentReference(contextId).createVersionUnspecificReference().toString());
                            }.bind(this));
                        }.bind(this));
                    }, this);
                }.bind(this));
            }, this);
            return promiseAll(promises);
        },

        copy: function (source, target) {
            return this._isContentTypeAllowed(source, target).then(function (isContentTypesAllowed) {

                if (!isContentTypesAllowed) {
                    return this._showContentTypeAlert();
                }

                var isLinkSupported = this._isLinkSupported(target.typeIdentifier);

                return this._newItemConfirmation(true, !isLinkSupported).then(function (choice) {

                    var contentItems = source.map(function (item){
                        return lang.mixin({ contextId: item.contextId }, item.data);
                    });

                    return this.pasteItems(contentItems, target, true, null, choice).then(function () {
                        topic.publish("itemsPasted");
                    });
                }.bind(this));
            }.bind(this));
        },

        move: function (source, target) {
            // summary:
            //      Move source items to target

            if (!target.contentLink) {
                target = this.store.get(target);
            }

            return when(target).then(function (targetContent) {
                return this._isContentTypeAllowed(source, targetContent).then(function (isContentTypesAllowed) {

                    if (!isContentTypesAllowed) {
                        return this._showContentTypeAlert();
                    }

                    var contentItems = source.map(function (item) {
                        return lang.mixin({ contextId: item.contextId }, item.data);
                    });

                    return this.pasteItems(contentItems, targetContent, false, null, "move").then(function () {
                        topic.publish("itemsPasted");
                    });
                }.bind(this));
            }.bind(this));
        },

        canCut: function (item) {
            // summary:
            //      disable cutting when entry doesn't belong to current category
            var isRelated = false;
            if (item.properties) {
                isRelated = item.properties.isRelatedToCurrentCategory;
            }
            return isRelated && this.inherited(arguments);
        },

        onDeleted: function (deletedItems) {
            // summary:
            //		Published a "catalogContentDeleted" topic when all rows are deleted.

            topic.publish("catalogContentDeleted", deletedItems);
        },

        remove: function (items) {
            // summary:
            //      Removes the specified items from the catalog


            // since ecf does not handle multiple async delete requests very well
            // we're using a separate delete controller to batch delete multiple items
            var urlToDeleteController = routes.getActionPath({
                moduleArea: "EPiServer.Commerce.Shell",
                controller: "Delete",
                action: "Delete"
            }),
                contentReferences = array.map(items, function (item) {
                    return item.data.contentLink;
                }),

                params = {
                    url: urlToDeleteController,
                    postData: { contentReferences: contentReferences },
                    handleAs: "json",
                    xsrfProtection: true
                },

                postRequest = this.xhrHandler.xhr("POST", params),
                deleteDeferred = new Deferred();

            when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
                this.getAncestors(currentContext, lang.hitch(this, function (ancestors) {
                    when(postRequest, lang.hitch(this, function () {
                        array.some(items, function (item) {
                            if (ContentReference.compareIgnoreVersion(currentContext.id, item.data.contentLink) && item.data.parentLink) {
                                // we're deleting the currently selected item and need to change selection.
                                this.onSelect(item.data.parentLink, true);
                                return true;
                            } else {
                                return array.some(ancestors, function (ancestor) {
                                    if (ContentReference.compareIgnoreVersion(ancestor.contentLink, item.data.contentLink) && item.data.parentLink) {
                                        // we're deleting an ancestor to the currently selected item and need to change selection.
                                        this.onSelect(item.data.parentLink, true);
                                        return true;
                                    }
                                }, this);
                            }
                        }, this);

                        //since we're deleting in a separate controller we need to tell the structure store that items are deleted.
                        var promises = array.map(contentReferences, function (contentLink) {
                            return this.store.remove(contentLink);
                        }, this);
                        when(promiseAll(promises), lang.hitch(this, function () {
                            this.onDeleted(items);
                            deleteDeferred.resolve(items);
                        }));
                    }), lang.hitch(this, function (errorResponse) {
                        topic.publish("/epi/cms/action/delete/error", errorResponse);
                    }));
                }));
            }));
            return deleteDeferred.promise;
        },

        _isContentTypeAllowed: function (items, target) {
            return this.contentTypeStore.query({ query: "getavailablecontenttypes", parentReference: target.contentLink })
                .then(function (contentTypes) {

                    var availableTypeIds = contentTypes.map(function (contentType) {
                        return contentType.id;
                    });

                    return items.every(function (item) {
                        if (!item) {
                            return false;
                        }
                        var contentTypeID = item.dndData ? item.dndData.data.contentTypeID : item.data ? item.data.contentTypeID : item.contentTypeID;
                        return availableTypeIds.indexOf(contentTypeID) > -1;
                    });
                });
        },

        _isLinkSupported: function (dataType) {
            return this.typeDescriptorManager.isBaseTypeIdentifier(dataType, ModelSupport.contentTypeIdentifier.entryContentBase) ||
                this.typeDescriptorManager.isBaseTypeIdentifier(dataType, ModelSupport.contentTypeIdentifier.nodeContent);
        },

        isSupportedType: function (dataType) {
            var isSupportedType = this.inherited(arguments);
            var inheritFromAnyContainedType = array.some(this.containedTypes, function (containedType) {
                return this.typeDescriptorManager.isBaseTypeIdentifier(dataType, containedType);
            }, this);
            return isSupportedType || inheritFromAnyContainedType;
        }
    });
});