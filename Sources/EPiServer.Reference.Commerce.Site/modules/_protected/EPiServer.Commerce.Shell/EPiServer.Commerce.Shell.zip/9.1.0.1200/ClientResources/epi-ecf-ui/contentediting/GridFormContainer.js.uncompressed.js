require({cache:{
'url:epi-ecf-ui/contentediting/templates/GridFormContainer.html':"<div class='epi-containerLayout clearfix'>\n    <div class='epi-formsHeaderContainer'>\n        <h2>${title}</h2>\n        <p data-dojo-attach-point='helpTextNode'></p>\n    </div>\n    <ul data-dojo-attach-point='containerNode'></ul>\n</div>"}});
define("epi-ecf-ui/contentediting/GridFormContainer", [
// dojo
    "dojo/_base/declare",
// epi
    "epi/shell/layout/SimpleContainer",
// resources
    "dojo/text!./templates/GridFormContainer.html",
    "epi/i18n!epi/cms/nls/commerce.groups"
], function(
// dojo
    declare,
// epi
    SimpleContainer,
// resources
    template,
    resources
){
    return declare([SimpleContainer], {

        templateString: template,

        buildRendering: function(){
            this.inherited(arguments);

            var groupResources = resources[this.name.toLowerCase()];

            if (groupResources && groupResources.help) {
                this.set("helpText", groupResources.help);
            }
        },

        _setHelpTextAttr: { node: "helpTextNode", type: "innerHTML" }
    });
});