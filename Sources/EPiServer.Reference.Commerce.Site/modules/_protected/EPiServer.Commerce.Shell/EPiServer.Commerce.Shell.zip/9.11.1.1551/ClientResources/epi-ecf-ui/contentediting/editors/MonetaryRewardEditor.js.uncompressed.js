require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/MonetaryRewardEditor.html':"﻿<div class=\"epi-monetary-reward\">\n    <ul class=\"epi-form-container__section\">\n        <li class=\"epi-form-container__section__row epi-form-container__section__row--field\">\n            <input type=\"radio\"\n                   title=\"${resources.percentageradiobuttontooltip}\"\n                   data-dojo-type=\"dijit/form/RadioButton\"\n                   data-dojo-attach-point=\"usePercentage\"\n                   name=\"useAmounts_${id}\"\n                   id=\"usePercentage_${id}\" />\n            <label for=\"usePercentage_${id}\"\n                   title=\"${resources.percentageradiobuttontooltip}\">${resources.usepercentage}</label>\n            <div data-dojo-attach-point=\"percentageContainer\" class=\"dijit dijitInline\">\n                <div data-dojo-attach-point=\"percentage\"\n                     data-dojo-type=\"dijit/form/NumberSpinner\"\n                     data-dojo-props=\"constraints: { min: 0, max: 100 }\" />\n                title=\"${resources.percentagevaluetooltip}\" />\n            </div>\n            <span>%</span>\n        </li>\n\n        <li class=\"epi-form-container__section__row epi-form-container__section__row--field\">\n            <input type=\"radio\"\n                   title=\"${resources.moneylistradiobuttontooltip}\"\n                   data-dojo-type=\"dijit/form/RadioButton\"\n                   data-dojo-attach-point=\"useAmounts\"\n                   name=\"useAmounts_${id}\"\n                   id=\"useAmounts_${id}\" />\n            <label for=\"useAmounts_${id}\"\n                   title=\"${resources.moneylistradiobuttontooltip}\">${resources.useamounts}</label>\n            <div data-dojo-attach-point=\"moneyListContainer\" class=\"dijit dijitInline\">\n                <div data-dojo-attach-point=\"moneyList\"\n                     data-dojo-type=\"epi-ecf-ui/contentediting/editors/MoneyListEditor\" />\n            </div>\n        </li>\n    </ul>\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/MonetaryRewardEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/keys",
// dijit
    "dijit/_WidgetBase",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_TemplatedMixin",
    "dijit/form/NumberSpinner",
    "dijit/form/RadioButton",
// epi
    "epi/shell/widget/_FocusableMixin",
// epi-ecf-ui
    "./MoneyListEditor",
// template
    "dojo/text!./templates/MonetaryRewardEditor.html",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.monetaryreward"
], function (
// dojo
    declare,
    lang,
    domStyle,
    keys,
// dijit
    _WidgetBase,
    _WidgetsInTemplateMixin,
    _TemplatedMixin,
    NumberSpinner,
    RadioButton,
// epi
    _FocusableMixin,
// epi-ecf-ui
    MoneyListEditor,
// template
    template,
// resources
    resources
) {
    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _FocusableMixin], {
        // summary:
        //      The editor used when editing an instance of EPiServer.Commerce.Marketing.MonetaryReward
        // tags:
        //      internal

        templateString: template,

        resources: resources,

        postCreate: function () {
            this.inherited(arguments);
            this.own(
                this.moneyList.on("change", lang.hitch(this, this._onChangeCallback)),
                this.percentage.on("change", lang.hitch(this, this._onChangeCallback)),
                this.useAmounts.on("change", lang.hitch(this, this._useAmountsChanged)),
                this.percentage.on("keydown",lang.hitch(this, this._onPercentageKeyDown))
            );
        },

        _onChangeCallback: function () {
            this.onChange(this.get("value"));
        },

        _useAmountsChanged: function (newValue) {
            domStyle.set(this.moneyListContainer, "display", newValue ? "" : "none");
            domStyle.set(this.percentageContainer, "display", newValue ? "none" : "");

            this.percentage.set("required", !newValue);
            this._onChangeCallback();
        },

        _onPercentageKeyDown: function(event){
            if (event.keyCode === keys.ENTER) {
                // Hitting the ENTER key should enable
                // any existing save button on the parent form.
                this.percentage.set("value", this.percentage.get("value"));
            }
        },

        _setValueAttr: function (value) {
            this.moneyList.set("value", value.amounts);
            this.percentage.set("value", value.percentage);
            this.useAmounts.set("checked", value.useAmounts);
            this.usePercentage.set("checked", !value.useAmounts);
        },

        _getValueAttr: function () {
            var useAmounts = this.useAmounts.get("checked");

            if (useAmounts) {
                return {
                    amounts: this.moneyList.get("value"),
                    useAmounts: useAmounts
                };
            }

            return {
                percentage: this.percentage.get("value"),
                useAmounts: useAmounts
            };
        },

        isValid: function () {
            return this.useAmounts.get("checked") ? this.moneyList.isValid() : this.percentage.isValid();
        },

        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            // tags:
            //    public, callback
        }
    });
});