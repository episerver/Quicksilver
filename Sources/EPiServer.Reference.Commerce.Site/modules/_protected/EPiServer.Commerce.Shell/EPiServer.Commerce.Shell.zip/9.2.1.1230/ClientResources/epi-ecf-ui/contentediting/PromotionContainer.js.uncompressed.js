require({cache:{
'url:epi-ecf-ui/contentediting/templates/PromotionContainer.html':"<div>\n    <div class=\"epi-grid__header\">\n        <h1>\n            <span data-dojo-attach-point=\"headingTextNode\"></span>:&nbsp;<span data-dojo-attach-point=\"contentTypeNameNode\"></span>\n        </h1>\n    </div>\n    <div class=\"epi-formsHeaderContainer\">\n        <h2 data-dojo-attach-point=\"contentTypeDescriptionNode\"></h2>\n    </div>\n    <ul data-dojo-attach-point=\"containerNode\" class=\"epi-form-container__section\"></ul>\n</div>"}});
define("epi-ecf-ui/contentediting/PromotionContainer", [
// dojo
    "dojo/_base/declare",
// epi
    "epi/shell/layout/SimpleContainer",
    "epi/shell/TypeDescriptorManager",
// resources
    "dojo/text!./templates/PromotionContainer.html"
], function(
// dojo
    declare,
// epi
    SimpleContainer,
    TypeDescriptorManager,
// resources
    template
){
    return declare([SimpleContainer], {

        templateString: template,

        contentType: null,

        buildRendering: function(){
            this.inherited(arguments);
            var headingText = TypeDescriptorManager.getResourceValue(this.contentType.typeIdentifier, "create");
            this.set("header", headingText);
            this.set("contentTypeName", this.contentType.name);
            this.set("contentTypeDescription", this.contentType.description || '');
        },

        _setHeaderAttr: { node: "headingTextNode", type: "innerHTML" },

        _setContentTypeNameAttr: { node: "contentTypeNameNode", type: "innerHTML" },

        _setContentTypeDescriptionAttr: { node: "contentTypeDescriptionNode", type: "innerHTML" }

    });
});