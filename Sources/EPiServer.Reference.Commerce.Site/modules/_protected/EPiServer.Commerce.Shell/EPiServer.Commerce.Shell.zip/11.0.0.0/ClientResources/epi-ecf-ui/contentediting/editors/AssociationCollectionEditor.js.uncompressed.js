﻿define("epi-ecf-ui/contentediting/editors/AssociationCollectionEditor", [
// dojo
    "dojo/aspect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

// epi
    "epi/dependency",

// epi cms
    "epi-cms/core/ContentReference",

// epi ecf
    "../viewmodel/AssociationCollectionEditorModel",
    "../../store/CompositeKey",
    "./_BaseEntryCollectionEditorGrid",
    "./LinkEditEditor",
    "../ModelSupport",

// resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.associationcollectioneditor"
],
function (
// dojo
    aspect,
    declare,
    lang,
    when,

// epi
    dependency,

// epi cms
    ContentReference,

// epi ecf
    AssociationCollectionEditorModel,
    CompositeKey,
    _BaseEntryCollectionEditorGrid,
    LinkEditEditor,
    ModelSupport,

// resources
    resources
) {
    var collectionEditor = declare([_BaseEntryCollectionEditorGrid], {

        resources: resources,

        deleteConfirmationTitle: resources.deleteconfirmation.title,

        deleteConfirmationDescription: resources.deleteconfirmation.description,

        modelType: AssociationCollectionEditorModel,

        storeKey: "epi.commerce.association",

        itemType: "EPiServer.Commerce.Shell.Rest.Models.AssociationModel",

        dndSourceTypes: [ModelSupport.linkTypeIdentifier.association],

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.entryContentBase, ModelSupport.linkTypeIdentifier.association],

        itemEditorTypes: [ModelSupport.contentTypeIdentifier.entryContentBase],

        includedColumns: ["ContentTypeIdentifier", "Name", "Code", "Path", "GroupName"],

        editableColumns: ["GroupName"],

        _createStore: function () {
            // Prepare store capable of doing remove/re-add on changes that affect composite keys
            return new CompositeKey(dependency.resolve("epi.storeregistry").get(this.storeKey), ["groupName", "type"], true);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.own(
                // Since grid will not be able to update the row due to the changed Id, we force a refresh
                aspect.after(this._store, "removeReAdd", lang.hitch(this, function (promise) {
                    when(promise).then(lang.hitch(this, function () {
                        this.grid.refresh();
                    }));
                }))
            );
        },

        _updateGridQuery: function(value){
            this.grid.set("query", { referenceId: new ContentReference(value).createVersionUnspecificReference().toString() });
        },

        _createItem: function (targetLink, name) {
            return {
                name: name || targetLink,
                sortOrder: 0,
                source: this.model.get("contentLink"),
                target: targetLink
            };
        }
    });

    return declare([LinkEditEditor], {

        resources: resources,

        gridCollectionType: collectionEditor

    });

});
