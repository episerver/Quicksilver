﻿define("epi-cms/contentediting/command/StartWorkflow", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/dom-class",

// epi
    "epi-cms/ApplicationSettings",
    "epi-cms/contentediting/command/_LegacyDialogCommandBase",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.command.startworkflow"
// resources
], function (
// dojo
    declare,
    lang,

    domClass,

// epi
    ApplicationSettings,
    _LegacyDialogCommandBase,
// resources
    resources
) {

    return declare([_LegacyDialogCommandBase], {
        // summary:
        //      A command for starting a new workflow using the StartWorkflow plug-in from the legacy CMS UI.
        //      When executed, a dialog showing the start workflow ui is opened.
        // tags:
        //      internal

        label: resources.label,

        dialogPath: "Edit/StartWorkflow.aspx",

        raiseCloseEvent: true,

        postscript: function() {
            this.inherited(arguments);

            //Hide the command if workflows are disabled
            this.set("isAvailable", ApplicationSettings.isWorkflowsEnabled);
        },

        getRouteParams: function () {
            // summary:
            //      Override to customize the parameters used for getting the route url for the opened dialog

            return lang.mixin(this.inherited(arguments), { "id": this.getContentReference(true) });
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var isPage = lang.getObject("model.contentData.capabilities.isPage", false, this);
            this.set("canExecute", !!isPage);
        },

        getDialogParams: function() {
            return {
                dialogTitle: resources.label,
                // Custom query to get the legacy buttons
                legacyButtonQuery: "div.epi-buttonContainer span.epi-cmsButton, span.epi-cmsButton>input.epi-cmsButton-Cancel",
                onMapDialogButton: function (/*DOM*/legacyButton) {
                    // All buttons except the cancel button should show up in the wrapping chrome
                    return !(legacyButton && domClass.contains(legacyButton, "epi-cmsButton-Cancel"));
                },
                showCloseButton: true
            };
        }
    });
});