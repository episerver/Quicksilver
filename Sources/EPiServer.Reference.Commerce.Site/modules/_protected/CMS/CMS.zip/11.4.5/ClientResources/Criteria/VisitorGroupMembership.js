dojo.require("epi-cms.ErrorDialog");
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.store.DataStore");
dojo.require('epi.routes');

(function () {
    return {
        uiCreated: function (namingContainer, settings) {
            var url = epi.routes.getActionPath({moduleArea: "CMS", controller: "VisitorGroupMembership", action: "GetIncludableVisitorGroups", visitorGroupId: this.visitorGroupId});
            dojo.xhrGet({
                url: url,
                handleAs: 'json',
                preventCache: true,
                error: epi.cms.ErrorDialog.showXmlHttpError,
                load: function (jsonData) {
                    var stateStore = new dojo.data.ItemFileReadStore({
                        data: jsonData
                    });

                    var vgid = dijit.byId(namingContainer + 'VisitorGroupId');
                    vgid.store = new dojo.store.DataStore({ store: stateStore });

                    if (settings && settings.VisitorGroupId) {
                        stateStore.fetchItemByIdentity({
                            identity: settings.VisitorGroupId,
                            onItem: function (group) {
                                if (group) {
                                    vgid.set('value', settings.VisitorGroupId);
                                }
                            }
                        });
                    }
                }
            });
        }
    };
})();
