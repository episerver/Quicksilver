dojo.require("epi-cms.ErrorDialog");
dojo.require("epi.routes");

(function () {
    return {
        uiCreated: function (namingContainer) {
            var categorySelectorWidget = dijit.byId(namingContainer + 'SelectedCategory');

            var updateMaxNumberOfPages = function (newCategoryId) {
                // Fetch the count of pages using the category, and update the constraints of the input as well as the display.
                var url = epi.routes.getActionPath({moduleArea: "CMS", controller: "VisitedCategories", action: "GetNumberOfPagesUsingCategory"});
                dojo.xhrPost({
                    url: url,
                    content: {
                        categoryId: newCategoryId
                    },
                    handleAs: 'json',
                    error: epi.cms.ErrorDialog.showXmlHttpError,
                    load: function (data, ioArgs) {
                        var numberOfPagesUsingCategory = data.numberOfPagesUsingCategory;

                        var numberOfPagesWidget = dijit.byId(namingContainer + 'NumberOfPageViews');
                        var numberOfPagesUsingCategoryDislayElement = dojo.byId(namingContainer + 'numberOfPagesUsingCategoryDislay');

                        numberOfPagesWidget.constraints.max = numberOfPagesUsingCategory;
                        numberOfPagesUsingCategoryDislayElement.innerHTML = numberOfPagesUsingCategory;
                    }
                });
            };

            dojo.connect(categorySelectorWidget, 'onChange', null, updateMaxNumberOfPages);

            // Trigger the updateConstraints once on first load.
            updateMaxNumberOfPages(categorySelectorWidget.value);
        }
    };
})();
