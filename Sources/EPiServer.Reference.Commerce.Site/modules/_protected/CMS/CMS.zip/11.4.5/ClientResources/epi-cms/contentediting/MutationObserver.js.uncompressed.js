define("epi-cms/contentediting/MutationObserver", [
    "dojo/_base/declare",
    "dojo/Evented"
], function (
    declare,
    Evented
) {
    return declare([Evented], {
        // summary:
        //      Sets up mutation observers on data-epi-property-name attribute to react on changes in the DOM
        // tags:
        //      internal

        // _mutationObserverHandles: [private] Array
        //      Mutation observer handles
        _mutationObserverHandles: [],

        setup: function (doc) {
            // summary:
            //      Sets up observers to react on changes in the dom and publishes dom-updated event.
            //      Disconnects all the observers on teardown.
            // tags:
            //      public

            this.teardown();

            this._observeEpiProperties(doc);

            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    var nodes = Array.prototype.slice.call(mutation.addedNodes);
                    nodes.forEach(this._observeEpiProperties.bind(this));
                }, this);
            }.bind(this));
            observer.observe(doc, {
                childList: true,
                subtree: true
            });
            this._mutationObserverHandles.push(observer);
        },
        teardown: function () {
            this._mutationObserverHandles.forEach(function (observer) {
                observer.disconnect();
            });
            this._mutationObserverHandles = [];
        },
        _observeEpiProperties: function (target) {
            // If it is not a node type or document type make an early exit
            // this filters #text and #comments nodes for example and much more
            // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
            if (target.nodeType !== Node.ELEMENT_NODE && target.nodeType !== Node.DOCUMENT_NODE) {
                return;
            }

            var nodes;
            if (target.attributes && target.attributes["data-epi-property-name"]) {
                nodes = [target];
            } else {
                var result = target.querySelectorAll("[data-epi-property-name]");
                nodes = Array.prototype.slice.call(result);
            }

            this._publishEvent();
            nodes.forEach(function (node) {
                var observer = new MutationObserver(this._publishEvent.bind(this));
                observer.observe(node, {
                    attributes: true,
                    attributeFilter: ["data-epi-property-name"]
                });
                this._mutationObserverHandles.push(observer);
            }, this);
        },
        _publishEvent: function () {
            this.emit("dom-updated");
        }
    });
});
